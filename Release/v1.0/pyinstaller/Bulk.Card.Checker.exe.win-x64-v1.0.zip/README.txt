-----------------
Bulk Card Checker
-----------------
This applicatiopn take a list of games and tells you if they have Steam cards associated with them.


See the latest version of the readme file at https://github.com/DanielZa2/HasCardsTool/blob/master/README.md
